
public class Peixe extends Animal{
	private String caracteristica;
	
	public Peixe() {
		super();
	}

	public Peixe(String nome, float comprimento, int nroDePatas, String ambiente, float velocidadeMedia) {
		super(nome, comprimento, nroDePatas, ambiente, velocidadeMedia);
		// TODO Auto-generated constructor stub
	}
	
	public Peixe(String nome, float comprimento, int nroDePatas, String ambiente, float velocidadeMedia, String caracteristica) {
		super(nome, comprimento, nroDePatas, ambiente, velocidadeMedia);
		setCaracteristica(caracteristica);
		// TODO Auto-generated constructor stub
	}

	public String getCaracteristica() {
		return caracteristica;
	}

	public void setCaracteristica(String caracteristica) {
		this.caracteristica = caracteristica;
	}



	@Override
	public String toString() {
		return "Peixe [caracteristica=" + caracteristica + ", toString()=" + super.toString()
	 + "]";
	}
	
	public void dadosPeixe() {
		
		System.out.println(caracteristica +super.toString());
	
	
	}
}
