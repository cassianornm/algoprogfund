
public class Mamifero extends Animal{
	private String alimento;
	
	public Mamifero() {
		super();
	}

	public Mamifero(String nome, float comprimento, int nroDePatas, String ambiente, float velocidadeMedia) {
		super(nome, comprimento, nroDePatas, ambiente, velocidadeMedia);
		// TODO Auto-generated constructor stub
	}
	
	public Mamifero(String nome, float comprimento, int nroDePatas, String ambiente, float velocidadeMedia, String alimento) {
		super(nome, comprimento, nroDePatas, ambiente, velocidadeMedia);
		setAlimento(alimento);
		// TODO Auto-generated constructor stub
	}

	public String getAlimento() {
		return alimento;
	}

	public void setAlimento(String alimento) {
		this.alimento = alimento;
	}



	@Override
	public String toString() {
		return "Peixe [caracteristica=" + alimento + ", toString()=" + super.toString()
	 + "]";
	}
	
	public void dadosPeixe() {
		
		System.out.println(getAlimento() + super.toString());
	
	
	}
}
