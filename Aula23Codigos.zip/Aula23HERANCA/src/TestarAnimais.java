
public class TestarAnimais {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Mamifero camelo = new Mamifero();
		camelo.setNome("Camelo");
		camelo.setComprimento(150);
		camelo.setNroDePatas(4);
		camelo.setAlimento("Terra");
		camelo.setVelocidadeMedia(2.0f);
		
		camelo.dados();
		
		Peixe tubarao = new Peixe("Tubarao", 300, 0, "Agua", 1.5f, "Cinzento");
		tubarao.dadosPeixe();

	}

}
