
public class Animal {
	
	private String nome;
	private float comprimento;
	private int nroDePatas;
	private String cor;
	private String ambiente;
	private float velocidadeMedia;
	
	
	public Animal() {}
	
	public Animal(String nome, float comprimento, int nroDePatas,
			 String ambiente,float velocidadeMedia) {
		
		setNome(nome);
		setComprimento(comprimento);
		setNroDePatas(nroDePatas);
		setAmbiente(ambiente);
		setVelocidadeMedia(velocidadeMedia);
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public float getComprimento() {
		return comprimento;
	}
	public void setComprimento(float comprimento) {
		this.comprimento = comprimento;
	}
	public int getNroDePatas() {
		return nroDePatas;
	}
	public void setNroDePatas(int nroDePatas) {
		this.nroDePatas = nroDePatas;
	}
	public String getCor() {
		return cor;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	public String getAmbiente() {
		return ambiente;
	}
	public void setAmbiente(String ambiente) {
		this.ambiente = ambiente;
	}
	public float getVelocidadeMedia() {
		return velocidadeMedia;
	}
	public void setVelocidadeMedia(float velocidadeMedia) {
		this.velocidadeMedia = velocidadeMedia;
	}
	@Override
	public String toString() {
		return "Animal [nome=" + nome + ", comprimento=" + comprimento + ", nroDePatas=" + nroDePatas + ", cor=" + cor
				+ ", ambiente=" + ambiente + ", velocidadeMedia=" + velocidadeMedia + "]";
	}
	

	public void dados() {
		System.out.println(getNome() + getComprimento() + getNroDePatas() + getAmbiente() + getVelocidadeMedia());
	}
	
	


}
