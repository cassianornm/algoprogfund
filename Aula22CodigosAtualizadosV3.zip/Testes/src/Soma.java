
import org.junit.Assert;
import org.junit.Test;

public class Soma {
	
	
	
	
	public int soma(int x, int y) {
		
		return (x+y);
	}
	
	@Test
	public void testeConfiguracao(){
		Assert.assertEquals(2, soma(1,1), 0);
		
	}

	
	
	
}
