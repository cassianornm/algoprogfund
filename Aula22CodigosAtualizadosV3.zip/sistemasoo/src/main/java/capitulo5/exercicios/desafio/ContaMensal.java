package capitulo5.exercicios.desafio;

public interface ContaMensal {
    public float calcularCustoMensal();
}
