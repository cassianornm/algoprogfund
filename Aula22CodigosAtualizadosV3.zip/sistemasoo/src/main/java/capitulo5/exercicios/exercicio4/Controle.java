package capitulo5.exercicios.exercicio4;

public interface Controle {
    public void botaoA(Personagem personagem);
    public void botaoB(Personagem personagem);
}
