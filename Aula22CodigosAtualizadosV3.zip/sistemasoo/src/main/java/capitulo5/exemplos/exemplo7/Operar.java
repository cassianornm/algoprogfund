package capitulo5.exemplos.exemplo7;

public interface Operar {

    public void ligar();
}
