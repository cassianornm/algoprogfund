package capitulo3.exercicios.exercicio1;

public class Ex01 {
    public static void main(String[] args) {
        System.out.println("Pablo Rangel");
        System.out.println("José Gomes de Carvalho Júnior");
    }
}
