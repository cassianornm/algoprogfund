package capitulo3.exercicios.exercicio3;

public class Ex03 {
    public static void main(String[] args) {
        int x,y,z;
        x=3;
        y=4;
        z=2;
        System.out.println(x*y/z);
    }
}
