package capitulo3.exercicios.exercicio11;

public class Ex11 {
    public static void main(String[] args) {
        int i =10000;
        while (i > 0){
            System.out.println(i);
            i--;
        }
    }
}
