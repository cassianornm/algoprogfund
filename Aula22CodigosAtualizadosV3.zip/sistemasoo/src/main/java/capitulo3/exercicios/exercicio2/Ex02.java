package capitulo3.exercicios.exercicio2;

public class Ex02 {
    public static void main(String[] args) {
        double x = 3.5;
        double y = 4.64;
        
        System.out.println("Valor de X: " + x);
        System.out.println("Valor de Y: " + y);
        
    }
}
