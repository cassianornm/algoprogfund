package capitulo3.exemplos.exemplo5;

public class OperadorResto {

    public static void main(String[] args) {
        int a, b;
        a = 10;
        b = 5;
        System.out.println((a + b) % 2);
    }
}
