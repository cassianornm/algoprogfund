package capitulo3.exemplos.exemplo20;

public class ExemploBasicoFor {

    public static void main(String[] args) {
        for (int i = 1; i <= 10; i++) {
            System.out.println(i);
        }
    }
}
