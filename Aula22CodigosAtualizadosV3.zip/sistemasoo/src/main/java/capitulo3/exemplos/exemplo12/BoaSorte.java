package capitulo3.exemplos.exemplo12;

public class BoaSorte {

    public static void main(String[] args) {
        System.out.println("Entre com um valor para x: ");
        int x = new java.util.Scanner(System.in).nextInt();
        if (x == 13) {
            System.out.println("Boa Sorte!");
        }
    }
}
