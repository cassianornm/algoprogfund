package capitulo3.exemplos.exemplo24;

public class ExemploBasicoVetor {

    public static void main(String[] args) {
        int[] idadeAlunos = new int[10];
    }
}
