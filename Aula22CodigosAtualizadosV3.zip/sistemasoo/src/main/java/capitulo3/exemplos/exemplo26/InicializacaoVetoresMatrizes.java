package capitulo3.exemplos.exemplo26;

public class InicializacaoVetoresMatrizes {

    public static void main(String[] args) {
        //vetor de 4 elementos
        int[] idadeAlunos = {20, 32, 45, 18};
        //matriz de 2 x 3 
        float[][] notasAlunos = {{10.0f, 3.4f}, {7.0f, 8.6f}};
    }
}
