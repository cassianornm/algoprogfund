package capitulo3.exemplos.exemplo2;

public class Tipos {

    public static void main(String[] args) {
        float produto, salarioBruto;
        int i, j, k;
        boolean fim;
        char opcao = 'A';
        double latitude = -23.02037222;
        salarioBruto = 5000.78f;
        i=10;
        String txt = "Texto";
    }
}
