package capitulo3.exemplos.exemplo8;

public class OlaMundoSegundaVersao {

    public static void main(String[] args) {
        System.out.println("Olá, mundo!");
        System.out.println("Em que ano nós estamos?");
        int ano = new java.util.Scanner(System.in).nextInt();
        System.out.println("Sério? " + ano + "?");
        System.out.println("Por quanto tempo eu deixei de existir?");
    }
}
