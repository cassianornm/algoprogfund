package capitulo3.exemplos.exemplo25;

public class ExemploBasicoMatriz {

    public static void main(String[] args) {
        float[][] notasAlunos = new float[10][3];
    }
}
