package capitulo3.exemplos.exemplo4;

public class OperadorDivisaoPontoFlutuante {

    public static void main(String[] args) {
        int a;
        float b;
        a = 10;
        b = 5;
        System.out.println((a + b) / 2);
    }
}
