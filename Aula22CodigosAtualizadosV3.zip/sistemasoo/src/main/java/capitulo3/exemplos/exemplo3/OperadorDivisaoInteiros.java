package capitulo3.exemplos.exemplo3;

public class OperadorDivisaoInteiros {

    public static void main(String[] args) {
        int a, b;
        a = 10;
        b = 5;
        System.out.println((a + b) / 2);
    }
}
