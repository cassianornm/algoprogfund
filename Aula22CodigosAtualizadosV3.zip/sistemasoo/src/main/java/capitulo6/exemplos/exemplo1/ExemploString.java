package capitulo6.exemplos.exemplo1;

public class ExemploString {
    public static void main(String[] args) {
        String txt = "Marina";
        System.out.println(txt.charAt(2));
        System.out.println(txt.indexOf("n"));
    }
} 
