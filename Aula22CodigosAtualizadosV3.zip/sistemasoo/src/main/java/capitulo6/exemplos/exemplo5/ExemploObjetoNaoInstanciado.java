package capitulo6.exemplos.exemplo5;

public class ExemploObjetoNaoInstanciado {

    public static void main(String[] args) {
        Pessoa pessoa = null;
        pessoa.setNome("Joshua");
    }
}
