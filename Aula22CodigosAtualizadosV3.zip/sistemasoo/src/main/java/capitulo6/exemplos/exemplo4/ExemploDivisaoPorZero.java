package capitulo6.exemplos.exemplo4;

public class ExemploDivisaoPorZero {

    public static void main(String[] args) {
        int x = 3;
        int y = 0;
        float res = x / y;
    }
}
