package capitulo6.exercicios.desafio;

public class Apresentador extends Funcionario{
    private TipoEnum tipo;

    public TipoEnum getTipo() {
        return tipo;
    }

    public void setTipo(TipoEnum tipo) {
        this.tipo = tipo;
    }
    
}
