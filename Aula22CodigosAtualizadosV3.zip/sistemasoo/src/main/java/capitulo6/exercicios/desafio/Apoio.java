package capitulo6.exercicios.desafio;

public class Apoio extends Funcionario{
    private EspecialidadeEnum especialidade;

    public EspecialidadeEnum getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(EspecialidadeEnum especialidade) {
        this.especialidade = especialidade;
    }
    
}
