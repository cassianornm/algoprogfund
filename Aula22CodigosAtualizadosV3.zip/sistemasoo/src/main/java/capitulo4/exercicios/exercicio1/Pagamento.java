package capitulo4.exercicios.exercicio1;

public interface Pagamento {
    public float calcularDespesa();
}
