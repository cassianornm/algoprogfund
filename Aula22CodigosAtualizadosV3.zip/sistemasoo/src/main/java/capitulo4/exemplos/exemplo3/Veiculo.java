package capitulo4.exemplos.exemplo3;

public class Veiculo {

}
